namespace empresa.Models{

    class Empresa{

        public int Id { get; set; }
        public string Fornecedor{ get; set; } = "";
        public string Nome {get; set; } = "";
        public string Endereco {get; set;} = "";
        public string Tax { get; set; } = "";
        public string Reg { get; set; } = "";
        public string CNPJ { get; set; } = "";

    }


}