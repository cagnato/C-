namespace cliente.Models{

    class Cliente{

        public int Id { get; set; }
        public string Nome{ get; set; } = "";
        public decimal CPF {get; set; }
        public string Endereco {get; set;} = "";
        public string Tel { get; set; } = "";
        public string Email { get; set; } = "";

    }


}