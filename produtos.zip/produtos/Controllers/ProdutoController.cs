using Microsoft.AspNetCore.Mvc;
using produto.Models;

namespace produto.Controllers
{
    public class ProdutoController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new Produto{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var produtos = new List<Produto>{
                new Produto{
                    Id = 1,
                    Nome = "Produto X",
                    Valor = 123.45m,
                    Cat = "Tecnologia",
                    Desc = "O melhor produto que você nunca teve.",
                    Entrada = "05/02/2014",
                    Resp = "DJ Rogerin",
                    Status = "Retido"
                },
                new Produto{
                    Id = 2,
                    Nome = "Produto Y",
                    Valor = 123.45m,
                    Cat = "Culinario",
                    Desc = "O melhor prato que você nunca teve.",
                    Entrada = "21/07/2024",
                    Resp = "Iarley Domingueiras",
                    Status = "Enviado"
                }
            };


            return View(produtos);
        }
    }
}
