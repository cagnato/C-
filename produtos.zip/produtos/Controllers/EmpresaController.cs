using Microsoft.AspNetCore.Mvc;
using empresa.Models;

namespace empresa.Controllers
{
    public class EmpresaController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new Produto{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var empresas = new List<Empresa>{
                new Empresa{
                    Id = 1,
                    Fornecedor = "FrangosChina",
                    Nome = "Empresa X",
                    Endereco = "Rua 1",
                    Tax = "R$20",
                    Reg = "Simples Nacional",
                    CNPJ = "12.345.678/0001-90"
                },
                new Empresa{
                    Id = 2,
                    Fornecedor = "BatatasFerro",
                    Nome = "Empresa Y",
                    Endereco = "Rua 2",
                    Tax = "R$20",
                    Reg = "Lucro Presumido",
                    CNPJ = "98.765.432/0001-12"
                }
            };


            return View(empresas);
        }
    }
}
