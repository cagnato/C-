using Microsoft.AspNetCore.Mvc;
using cliente.Models;

namespace cliente.Controllers
{
    public class ClienteController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new Produto{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var clientes = new List<Cliente>{
                new Cliente{
                    Id = 1,
                    Nome = "Senhor X",
                    CPF = 1234561233,
                    Endereco = "Rua y 951",
                    Tel = "9999-9999",
                    Email = "shaolinmatadordeporco@gmail.com"
                },
                new Cliente{
                    Id = 2,
                    Nome = "Senhor Y",
                    CPF = 1234567899,
                    Endereco = "Rua x 950",
                    Tel = "9999-9998",
                    Email = "flavindopneu@gmail.com"
                }
            };


            return View(clientes);
        }
    }
}
